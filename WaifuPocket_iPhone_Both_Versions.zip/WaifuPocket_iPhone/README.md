# Waifu Pocket — iPhone native + web app

Two implementations of an original desktop-pet-inspired Tamagotchi. Both include six character **presets** (Rem, Ram, Emilia, Hana, Yuki, Mika), a generic procedural chibi illustration with palette swaps, feeding, playing, napping, affection, chaos, and persistent local saves.

## Web / PWA (no Mac needed)

The `web/` folder is a complete installable Progressive Web App. To test locally:

```bash
cd web
python3 -m http.server 8000
```

Visit `http://localhost:8000` on your computer. To install on an iPhone, **host the `web/` folder on an HTTPS site** (for example, GitHub Pages or Netlify). Open the HTTPS URL in iPhone Safari, tap **Share → Add to Home Screen**. `file://` and ordinary HTTP hosting on a remote server do not provide reliable service-worker installation.

Once loaded and cached, the PWA can work offline. Local progress is per browser/device and is not synchronized with the native app.

## Native iOS app (Mac required)

The `ios/` folder contains SwiftUI source plus an **XcodeGen** project specification. On a Mac:

1. Install Xcode and XcodeGen (`brew install xcodegen`).
2. `cd ios && xcodegen generate`
3. Open `WaifuPocket.xcodeproj` in Xcode.
4. Set a unique bundle identifier and your Apple signing team in Xcode.
5. Select your iPhone or Simulator and press Run.

A small **WidgetKit Home Screen widget** is included. It currently shows a static invitation to open the app, **not live pet stats**. Sharing live stats with the widget requires adding an App Group entitlement to both targets and writing shared storage.

## Scope and limitations

- These are **starter projects**, not precompiled `.ipa` files. iOS binaries require Apple's build/signing toolchain.
- The chibi characters are procedural placeholder drawings with color variations. There are no licensed Re:Zero character sprites, voice clips, or official art bundled.
- Animation is a bobbing idle effect with occasional position shifts; full sprite-sheet animation is future work.
- The chaos slider controls playful in-app motion only; neither app can draw above other iOS apps or hijack the system cursor.
- No push notifications, Live Activities, cloud sync, or audio are included yet.
- Code is provided for development; native Xcode build and on-device behavior have not been verified in this environment.
