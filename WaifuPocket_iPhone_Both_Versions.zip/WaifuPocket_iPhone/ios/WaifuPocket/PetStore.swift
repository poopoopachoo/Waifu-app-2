import Foundation
import SwiftUI

struct Character: Identifiable {
    let name: String
    let hair: Color
    let outfit: Color
    let accent: Color
    var id: String { name }
}

let characters: [Character] = [
    .init(name: "Rem", hair: Color(red: 0.33, green: 0.74, blue: 0.91), outfit: .indigo, accent: .cyan),
    .init(name: "Ram", hair: .pink, outfit: .purple, accent: Color(red: 1, green: 0.85, blue: 0.9)),
    .init(name: "Emilia", hair: Color(red: 0.91, green: 0.91, blue: 0.98), outfit: .purple, accent: .white),
    .init(name: "Hana (Original)", hair: .orange, outfit: .red, accent: .yellow),
    .init(name: "Yuki (Original)", hair: .purple, outfit: .blue, accent: .mint),
    .init(name: "Mika (Original)", hair: .mint, outfit: .teal, accent: .green)
]

struct PetSave: Codable {
    var character = "Hana (Original)"
    var chaos = 50.0
    var fullness = 85.0
    var happiness = 85.0
    var energy = 85.0
    var affection = 50.0
    var lastTick = Date()
}

@MainActor final class PetStore: ObservableObject {
    @Published var state: PetSave
    @Published var speech = "Tap me! ♡"
    @Published var hop = 0
    private let key = "waifu-pocket-native-v1"

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode(PetSave.self, from: data) {
            state = saved
        } else { state = PetSave() }
        decay()
    }

    var selected: Character { characters.first(where: { $0.name == state.character }) ?? characters[3] }
    func save() {
        state.lastTick = Date()
        if let data = try? JSONEncoder().encode(state) { UserDefaults.standard.set(data, forKey: key) }
    }
    func decay() {
        let minutes = min(1440, max(0, Date().timeIntervalSince(state.lastTick) / 60))
        state.fullness = max(0, state.fullness - minutes * 0.20)
        state.happiness = max(0, state.happiness - minutes * 0.14)
        state.energy = max(0, state.energy - minutes * 0.10)
        state.affection = max(0, state.affection - minutes * 0.08)
        save()
    }
    func perform(_ action: String) {
        switch action {
        case "Feed": state.fullness = min(100, state.fullness + 25); speech = "Yummy! 🍰"
        case "Play": state.happiness = min(100, state.happiness + 20); state.energy = max(0, state.energy - 9); speech = "That was fun!"
        case "Nap": state.energy = min(100, state.energy + 30); speech = "Zzz... 💤"
        default:
            state.affection = min(100, state.affection + 9)
            state.happiness = min(100, state.happiness + 5)
            switch state.character {
            case "Rem": speech = "Ehehehe! ♡"
            case "Ram": speech = "Hmph!"; hop += 1
            case "Emilia": speech = "Thank you! ♡"
            default: speech = "Hehe~ ♡"
            }
        }
        save()
    }
}
