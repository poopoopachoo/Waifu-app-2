import SwiftUI

@main
struct WaifuPocketApp: App {
    @StateObject private var pet = PetStore()
    var body: some Scene {
        WindowGroup { ContentView().environmentObject(pet) }
    }
}
