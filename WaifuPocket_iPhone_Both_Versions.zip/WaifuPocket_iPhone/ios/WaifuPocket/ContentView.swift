import SwiftUI

struct ChibiView: View {
    let character: Character
    @State private var bob = false
    var body: some View {
        ZStack {
            Ellipse().fill(character.hair).frame(width: 122, height: 150).offset(y: -18)
            RoundedRectangle(cornerRadius: 28).fill(character.outfit).frame(width: 106, height: 115).offset(y: 67)
            RoundedRectangle(cornerRadius: 10).fill(character.accent).frame(width: 60, height: 18).offset(y: 29)
            Ellipse().fill(Color(red: 1, green: 0.88, blue: 0.82)).frame(width: 104, height: 110).offset(y: -22)
            Ellipse().fill(character.hair).frame(width: 113, height: 50).offset(y: -68)
            HStack(spacing: 28) {
                Ellipse().fill(Color(red: 0.28, green: 0.18, blue: 0.31)).frame(width: 13, height: 22)
                Ellipse().fill(Color(red: 0.28, green: 0.18, blue: 0.31)).frame(width: 13, height: 22)
            }.offset(y: -17)
            Text("ᴗ").font(.system(size: 24, weight: .bold)).foregroundStyle(.pink).offset(y: 12)
            Text("✿").font(.system(size: 34)).foregroundStyle(character.accent).offset(x: 52, y: -70)
        }
        .frame(width: 170, height: 240)
        .offset(y: bob ? -9 : 4)
        .animation(.easeInOut(duration: 1.25).repeatForever(autoreverses: true), value: bob)
        .onAppear { bob = true }
        .accessibilityLabel("Animated chibi pet, \(character.name)")
    }
}

struct ContentView: View {
    @EnvironmentObject private var pet: PetStore
    @State private var offset: CGSize = .zero
    @State private var dragOffset: CGSize = .zero
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HStack { Text("♡ Waifu Pocket").font(.largeTitle.bold()); Spacer() }
                Text(pet.state.fullness < 20 ? "Hungry 💔" : pet.state.energy < 20 ? "Sleepy 💤" : "Happy ♡")
                    .frame(maxWidth: .infinity, alignment: .trailing)
                ZStack {
                    RoundedRectangle(cornerRadius: 26).fill(LinearGradient(colors: [.purple, .pink.opacity(0.7), .indigo], startPoint: .top, endPoint: .bottom))
                    VStack {
                        Text(pet.speech).font(.headline).padding(10).background(.white, in: Capsule()).foregroundStyle(.purple)
                        Spacer()
                        ChibiView(character: pet.selected)
                            .id(pet.state.character)
                            .offset(x: offset.width + dragOffset.width, y: offset.height + dragOffset.height)
                            .onTapGesture { pet.perform("Pet") }
                            .gesture(DragGesture().onChanged { dragOffset = $0.translation }
                                .onEnded { value in offset.width = min(90, max(-90, offset.width + value.translation.width)); offset.height = min(40, max(-40, offset.height + value.translation.height)); dragOffset = .zero })
                        Spacer(minLength: 4)
                    }.padding()
                }.frame(height: 320)
                VStack(alignment: .leading, spacing: 15) {
                    Picker("Character", selection: Binding(get: { pet.state.character }, set: { pet.state.character = $0; pet.save() })) {
                        ForEach(characters) { Text($0.name).tag($0.name) }
                    }.tint(.pink)
                    HStack { Text("Chaos"); Spacer(); Text("\(Int(pet.state.chaos))%") }
                    Slider(value: Binding(get: { pet.state.chaos }, set: { pet.state.chaos = $0; pet.save() }), in: 0...100).tint(.pink)
                    stat("Fullness", pet.state.fullness)
                    stat("Happiness", pet.state.happiness)
                    stat("Energy", pet.state.energy)
                    stat("Affection", pet.state.affection)
                    HStack {
                        action("🍰 Feed", "Feed")
                        action("🎮 Play", "Play")
                    }
                    HStack {
                        action("💤 Nap", "Nap")
                        action("💕 Pet", "Pet")
                    }
                    Text("Progress is saved locally. iOS does not allow a pet to float above other apps.")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding().background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 24))
            }.padding()
        }
        .background(Color(red: 0.10, green: 0.06, blue: 0.17))
        .foregroundStyle(.white)
        .onReceive(Timer.publish(every: 30, on: .main, in: .common).autoconnect()) { _ in
            pet.decay()
            if Int.random(in: 0..<100) < Int(pet.state.chaos / 10) {
                withAnimation(.spring()) { offset.width = CGFloat.random(in: -80...80) }
            }
        }
    }
    private func stat(_ label: String, _ value: Double) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack { Text(label); Spacer(); Text("\(Int(value))") }
            ProgressView(value: value, total: 100).tint(.pink)
        }
    }
    private func action(_ label: String, _ kind: String) -> some View {
        Button(label) { pet.perform(kind) }
            .fontWeight(.semibold).frame(maxWidth: .infinity).padding(13)
            .background(.pink, in: RoundedRectangle(cornerRadius: 14))
            .foregroundStyle(Color(red: 0.2, green: 0.1, blue: 0.25))
    }
}
