import WidgetKit
import SwiftUI

struct PetEntry: TimelineEntry { let date: Date }
struct PetProvider: TimelineProvider {
    func placeholder(in context: Context) -> PetEntry { PetEntry(date: .now) }
    func getSnapshot(in context: Context, completion: @escaping (PetEntry) -> Void) { completion(PetEntry(date: .now)) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<PetEntry>) -> Void) {
        completion(Timeline(entries: [PetEntry(date: .now)], policy: .after(.now.addingTimeInterval(3600))))
    }
}
struct PetWidgetView: View {
    var entry: PetEntry
    var body: some View {
        VStack(spacing: 6) {
            Text("♡").font(.system(size: 45)).foregroundStyle(.pink)
            Text("Waifu Pocket").font(.headline)
            Text("Come say hi! ♡").font(.caption)
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
            .containerBackground(.purple.opacity(0.3), for: .widget)
    }
}
@main struct WaifuPocketWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "WaifuPocketWidget", provider: PetProvider()) { entry in PetWidgetView(entry: entry) }
            .configurationDisplayName("Waifu Pocket")
            .description("A cute reminder to visit your desktop pet.")
            .supportedFamilies([.systemSmall, .systemMedium])
    }
}
